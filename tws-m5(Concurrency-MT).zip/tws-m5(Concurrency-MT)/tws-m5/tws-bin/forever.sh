i = 1
while :; do  i = $(expr $i + 1); sleep 1; done;